﻿namespace SPORTS_MANAGEMENT
{
    partial class App_Body
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            button8 = new Button();
            button7 = new Button();
            Items = new Button();
            Ta = new Button();
            Borrower = new Button();
            Content = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.MenuHighlight;
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.MaximumSize = new Size(1027, 48);
            panel1.Name = "panel1";
            panel1.Size = new Size(1027, 48);
            panel1.TabIndex = 0;
            panel1.MouseDown += panel1_MouseDown;
            // 
            // button3
            // 
            button3.BackColor = Color.Red;
            button3.Font = new Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.ControlText;
            button3.ImageAlign = ContentAlignment.TopCenter;
            button3.Location = new Point(956, 7);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(54, 32);
            button3.TabIndex = 2;
            button3.Text = "X";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Constantia", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(880, 7);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(69, 32);
            button2.TabIndex = 1;
            button2.Text = "MINS";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Location = new Point(755, 8);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(117, 31);
            button1.TabIndex = 0;
            button1.Text = "LOG OUT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.MenuHighlight;
            panel2.Controls.Add(button8);
            panel2.Controls.Add(button7);
            panel2.Controls.Add(Items);
            panel2.Controls.Add(Ta);
            panel2.Controls.Add(Borrower);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 48);
            panel2.Margin = new Padding(4);
            panel2.Name = "panel2";
            panel2.Size = new Size(234, 489);
            panel2.TabIndex = 1;
            // 
            // button8
            // 
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(0, 399);
            button8.Name = "button8";
            button8.Size = new Size(234, 90);
            button8.TabIndex = 4;
            button8.Text = "ABOUT";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click_1;
            // 
            // button7
            // 
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(0, 299);
            button7.Name = "button7";
            button7.Size = new Size(234, 94);
            button7.TabIndex = 3;
            button7.Text = "SETTING";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // Items
            // 
            Items.FlatStyle = FlatStyle.Flat;
            Items.Location = new Point(0, 96);
            Items.Name = "Items";
            Items.Size = new Size(234, 94);
            Items.TabIndex = 1;
            Items.Text = "ITEMS";
            Items.UseVisualStyleBackColor = true;
            Items.Click += button5_Click;
            // 
            // Ta
            // 
            Ta.FlatStyle = FlatStyle.Flat;
            Ta.Location = new Point(0, 196);
            Ta.Name = "Ta";
            Ta.Size = new Size(234, 97);
            Ta.TabIndex = 2;
            Ta.Text = "TRANSACTION";
            Ta.UseVisualStyleBackColor = true;
            Ta.Click += button6_Click;
            // 
            // Borrower
            // 
            Borrower.FlatStyle = FlatStyle.Flat;
            Borrower.Location = new Point(0, 0);
            Borrower.Name = "Borrower";
            Borrower.Size = new Size(234, 90);
            Borrower.TabIndex = 0;
            Borrower.Text = "BORROWER";
            Borrower.UseVisualStyleBackColor = true;
            Borrower.Click += button4_Click;
            // 
            // Content
            // 
            Content.Dock = DockStyle.Right;
            Content.Location = new Point(237, 48);
            Content.MaximumSize = new Size(790, 489);
            Content.Name = "Content";
            Content.Size = new Size(790, 489);
            Content.TabIndex = 2;
            Content.Paint += Content_Paint;
            // 
            // App_Body
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1027, 537);
            Controls.Add(Content);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new Font("Constantia", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            MaximumSize = new Size(1027, 537);
            Name = "App_Body";
            Text = "App_Body";
            Load += App_Body_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel2;
        private Button Borrower;
        private Button button7;
        private Button Ta;
        private Button Items;
        private Button button8;
        private Panel Content;
    }
}