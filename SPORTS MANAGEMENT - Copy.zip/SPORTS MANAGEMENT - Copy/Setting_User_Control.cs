﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SPORTS_MANAGEMENT
{

    public partial class Setting_User_Control : UserControl
    {
        private static Setting_User_Control _instance;
        public static Setting_User_Control Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Setting_User_Control();
                }
                return _instance;
            }
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""E:\SPORTS MANAGEMENT\Sports_Database.mdf"";Integrated Security=True");
        public Setting_User_Control()
        {
            InitializeComponent();
        }

        public void refresh_dataGridView1()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SystemUpdate_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                dataGridView1.DataSource = DS.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(" " + ex);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Username button

            SqlCommand cmd = new SqlCommand("SystemUpdate_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@property", textBox1.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();

            refresh_dataGridView1();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Password button

            SqlCommand cmd = new SqlCommand("SystemUpdate_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@value", textBox2.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();

            refresh_dataGridView1();
        }
    }
}
