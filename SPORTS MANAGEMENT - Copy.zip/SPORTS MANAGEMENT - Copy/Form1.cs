using System.Data.SqlClient;

namespace SPORTS_MANAGEMENT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection ("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"E:\\SPORTS MANAGEMENT\\Sports_Database.mdf\";Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;

        private String getUsername()
        {
            //fetch data from database
            conn.Open ();
            String syntax = "SELECT Value From systemTable where Property = 'Username'";
            cmd = new SqlCommand (syntax, conn);
            dr = cmd.ExecuteReader ();
            dr.Read ();
            String temp = dr[0].ToString ();
            conn.Close();
            return temp;

        }

        private String getPassword()
        {
            //fetch data from database
            conn.Open();
            String syntax = "SELECT Value From systemTable where Property = 'Password'";
            cmd = new SqlCommand(syntax, conn);
            dr = cmd.ExecuteReader();
            dr.Read();
            String temp = dr[0].ToString();
            conn.Close();
            return temp;

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String Uname = getUsername(), Upass = getPassword(), name, pass;
            name = textBox1.Text;
            pass = textBox2.Text;

            if(name.Equals(Uname) && pass.Equals(Upass)) 
            {
                //login
               App_Body obj = new App_Body();
                this.Hide();
                obj.Show();
                MessageBox.Show("Login Sucessful");
            }
            else
            {
                // login fail
                MessageBox.Show("Login Failed");
            }
        }
    }
}
