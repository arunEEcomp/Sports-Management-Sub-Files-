﻿CREATE TABLE borrowerTable
(
	[USN] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [Student_Name] VARCHAR(50) NULL, 
    [Address] VARCHAR(50) NULL, 
    [Phone_No] INT NULL, 
    [Item1] INT NULL, 
    [Item2] INT NULL, 
    CONSTRAINT [FK_borrowerTable_ToTable] FOREIGN KEY (Item1) REFERENCES itemTable(accNo)
)
