﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SPORTS_MANAGEMENT
{
    public partial class Borrower_User_Control : UserControl
    {
        private static Borrower_User_Control _instance;
        public static Borrower_User_Control Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Borrower_User_Control();
                }
                return _instance;
            }
        }
        public Borrower_User_Control()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""E:\SPORTS MANAGEMENT\Sports_Database.mdf"";Integrated Security=True");


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void refresh_Data_Grid_View1()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllUSNData_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                Data_Grid_View1.DataSource = DS.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(" " + ex);
            }
        }

        private void Borrower_User_Control_Load(object sender, EventArgs e)
        {
            refresh_Data_Grid_View1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("SearchUSN_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@USN", textBox1.Text);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                Data_Grid_View1.DataSource = DS.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(" " + ex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            refresh_Data_Grid_View1();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Add button

            SqlCommand cmd = new SqlCommand("BorrowerAdd_SP", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@USN", textBox2.Text);
            cmd.Parameters.AddWithValue("@Name", textBox3.Text);
            cmd.Parameters.AddWithValue("@Addrese", textBox4.Text);
            cmd.Parameters.AddWithValue("@Phone_No", textBox5.Text);

            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
            }
            con.Close();

            refresh_Data_Grid_View1();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            // delete button
            try
            {
                SqlCommand cmd = new SqlCommand("BorrowerDelete_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("USN", textBox2.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("  <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                refresh_Data_Grid_View1();


            }
            catch (Exception ex)
            {
                MessageBox.Show(" " + ex);
            }
        }
    }
}
