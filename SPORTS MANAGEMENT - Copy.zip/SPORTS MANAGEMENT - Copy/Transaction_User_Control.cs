﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SPORTS_MANAGEMENT
{
    public partial class Transaction_User_Control : UserControl
    {
        private static Transaction_User_Control _instance;
        public static Transaction_User_Control Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Transaction_User_Control();
                }
                return _instance;
            }
        }
        public Transaction_User_Control()
        {
            InitializeComponent();
        }
        public void refresh_dataGridView1()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("ShowAllTansact_DataGrid_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                con.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                dataGridView1.DataSource = DS.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(" " + ex);
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Transaction_User_Control_Load(object sender, EventArgs e)
        {
            refresh_dataGridView1();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Transaction_User_Control_Load_1(object sender, EventArgs e)
        {

        }

        public string Item1, Item2, USN;

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"E:\\SPORTS MANAGEMENT\\Sports_Database.mdf\";Integrated Security=True");
        public SqlCommand cmd;
        public SqlDataReader dr;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                // Retrieve Item1
                string syntax = "SELECT Item1 FROM borrowerTable WHERE USN = @usn";
                cmd = new SqlCommand(syntax, con);
                cmd.Parameters.AddWithValue("@usn", textBox1.Text);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    label4.Text = dr["Item1"].ToString();
                }
                else
                {
                    label4.Text = "No data found";
                }
                dr.Close();

                // Retrieve Item2
                syntax = "SELECT Item2 FROM borrowerTable WHERE USN = @usn";
                cmd = new SqlCommand(syntax, con);
                cmd.Parameters.AddWithValue("@usn", textBox1.Text);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    label5.Text = dr["Item2"].ToString();
                }
                else
                {
                    label5.Text = "No data found";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            // to get borrowed_by


            try
            {
                con.Open();
                string syntax = "SELECT borrowerTable.USN FROM borrowerTable LEFT JOIN itemTable ON (borrowerTable.Item1 = itemTable.accNo OR borrowerTable.Item2 = itemTable.accNo) WHERE itemTable.accNo = @accNo OR (borrowerTable.Item1 = @accNo OR borrowerTable.Item2 = @accNo)";
                cmd = new SqlCommand(syntax, con);
                cmd.Parameters.AddWithValue("@accNo", textBox2.Text);
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    label8.Text = dr["USN"].ToString();
                }
                else
                {
                    label8.Text = "No data found";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string accNo = textBox2.Text;

            try
            {
                con.Open();

                // Fetch the current state of Item1 and Item2 for the given USN
                string syntax = "SELECT Item1, Item2 FROM borrowerTable WHERE USN = @USN";
                using (SqlCommand cmd = new SqlCommand(syntax, con))
                {
                    cmd.Parameters.AddWithValue("@USN", textBox1.Text);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            int item1 = dr.IsDBNull(0) ? 0 : Convert.ToInt32(dr["Item1"]);
                            int item2 = dr.IsDBNull(1) ? 0 : Convert.ToInt32(dr["Item2"]);

                            // Determine which item slot to set to null based on the current state
                            string updateSyntax;
                            if (item1 == Convert.ToInt32(accNo))
                            {
                                // Set Item1 to null
                                updateSyntax = "UPDATE borrowerTable SET Item1 = NULL WHERE USN = @USN";
                            }
                            else if (item2 == Convert.ToInt32(accNo))
                            {
                                // Set Item2 to null
                                updateSyntax = "UPDATE borrowerTable SET Item2 = NULL WHERE USN = @USN";
                            }
                            else
                            {
                                MessageBox.Show("The entered accNo does not match any issued item.");
                                return;
                            }

                            // Use a separate connection for the update command
                            using (SqlConnection updateCon = new SqlConnection(con.ConnectionString))
                            {
                                updateCon.Open();
                                using (SqlCommand updateCmd = new SqlCommand(updateSyntax, updateCon))
                                {
                                    updateCmd.Parameters.AddWithValue("@USN", textBox1.Text);
                                    try
                                    {
                                        updateCmd.ExecuteNonQuery();
                                        MessageBox.Show("Successfully returned the item.");
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("Error returning the item: " + ex.Message);
                                    }
                                }
                            }
                        }
                
                        else
                        {
                            MessageBox.Show("No borrower found with the entered USN.");
                        }

                        con.Close();

                    }
                }

                // now we need to insert the issue details into the transactionTable
                cmd = new SqlCommand("Transact_return_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@USN", textBox1.Text);
                cmd.Parameters.AddWithValue("@accNo", textBox2.Text);
                cmd.Parameters.AddWithValue("@authorized_by", textBox4.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            
            refresh_dataGridView1();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            label4.Text = "";
            label5.Text = "";
            label8.Text = "";

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


        private void button4_Click(object sender, EventArgs e)
        {
            // Determine which item slot to update based on the current state
            bool item1IsEmpty = string.IsNullOrWhiteSpace(label4.Text); // Assuming label4 displays Item1
            bool item2IsEmpty = string.IsNullOrWhiteSpace(label5.Text); // Assuming label5 displays Item2

            try
            {
                if (item1IsEmpty)
                {
                    // accNo must be updated in the Item1 slot
                    cmd = new SqlCommand("Transact_Update_Item1_SP", con);
                }
                else if (item2IsEmpty)
                {
                    // accNo must be updated in the Item2 slot
                    cmd = new SqlCommand("Transact_Update_Item2_SP", con);
                }
                else
                {
                    // Both Item1 and Item2 are occupied, handle accordingly
                    MessageBox.Show("Both items are currently issued. Cannot issue more items.");
                    return;
                }

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@accNo", textBox2.Text);
                cmd.Parameters.AddWithValue("@USN", textBox1.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                // now we need to insert the issue details into the transactionTable
                cmd = new SqlCommand("Transact_insert_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@USN", textBox1.Text);
                cmd.Parameters.AddWithValue("@accNo", textBox2.Text);
                cmd.Parameters.AddWithValue("@authorized_by", textBox4.Text);

                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" <<<INVALID SQL OPERATION>>>: \n" + ex);
                }
                con.Close();

                // Refresh the data to reflect the changes
                button1.PerformClick();
                MessageBox.Show("Successfully issued");
            }
            catch (Exception ex)
            {
                MessageBox.Show(" " + ex);
            }

            refresh_dataGridView1();

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            refresh_dataGridView1();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
