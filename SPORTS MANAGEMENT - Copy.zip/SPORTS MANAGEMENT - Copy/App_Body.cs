﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SPORTS_MANAGEMENT
{
    public partial class App_Body : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        public App_Body()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form obj = new Form1();
            this.Hide();
            obj.Show();
        }

        private void App_Body_Load(object sender, EventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!Content.Controls.Contains(Borrower_User_Control.Instance))
            {
                Content.Controls.Add(Borrower_User_Control.Instance);
                Borrower_User_Control.Instance.Dock = DockStyle.Fill;
                Borrower_User_Control.Instance.BringToFront();
            }
            else
            {
                Borrower_User_Control.Instance.BringToFront();
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!Content.Controls.Contains(Setting_User_Control.Instance))
            {
                Content.Controls.Add(Setting_User_Control.Instance);
                Setting_User_Control.Instance.Dock = DockStyle.Fill;
                Setting_User_Control.Instance.BringToFront();
            }
            else
            {
                Setting_User_Control.Instance.BringToFront();
            }

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!Content.Controls.Contains(Items_User_Control.Instance))
            {
                Content.Controls.Add(Items_User_Control.Instance);
                Items_User_Control.Instance.Dock = DockStyle.Fill;
                Items_User_Control.Instance.BringToFront();
            }
            else
            {
                Items_User_Control.Instance.BringToFront();
            }


        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!Content.Controls.Contains(Transaction_User_Control.Instance))
            {
                Content.Controls.Add(Transaction_User_Control.Instance);
                Transaction_User_Control.Instance.Dock = DockStyle.Fill;
                Transaction_User_Control.Instance.BringToFront();
            }
            else
            {
                Transaction_User_Control.Instance.BringToFront();
            }

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            if (!Content.Controls.Contains(About_User_Control.Instance))
            {
                Content.Controls.Add(About_User_Control.Instance);
                About_User_Control.Instance.Dock = DockStyle.Fill;
                About_User_Control.Instance.BringToFront();
            }
            else
            {
                About_User_Control.Instance.BringToFront();
            }
        }

        private void Content_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
